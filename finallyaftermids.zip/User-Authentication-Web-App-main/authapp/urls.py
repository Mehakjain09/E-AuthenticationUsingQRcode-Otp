from django.contrib import admin
from django.urls import path
from authapp import views
from . import views
from django.urls import path
#from .views import edit, dashboard, register
from django.urls import reverse_lazy
from django.contrib.auth.views import (LoginView, LogoutView, PasswordResetDoneView, PasswordResetView,
                                       PasswordResetCompleteView, PasswordResetConfirmView,
                                       PasswordChangeView, PasswordChangeDoneView,
                                       PasswordResetDoneView)

app_name = 'authapp'

urlpatterns = [

    path('verify/<auth_token>',views.verify,name="verify"),
    


    path('checkuser', views.checkuser, name='checkuser'),
    path('registeruser', views.registeruser, name='registeruser'),
    #path('register/', views.register, name='register'),
    #path('edit/', views.edit, name='edit'),
    #path('dashboard/', views.dashboard, name='dashboard'),
    #path('dashboard/', views.checkqr, name='dashboard'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('checkotp', views.checkotp, name='checkotp'), 
    path('sendotp/',views.sendotp,name='sendotp'),
    path('checkotp/',views.checkotp,name='checkotp'),

    path('sendqr/',views.sendqr,name='sendqr'),
    path('checkqr',views.checkqr,name='checkqr'),
    path('checkqr/',views.checkqr,name='checkqr'),

    path('choiceform/',views.choiceform, name="choiceform"),
    path('checkotpform/',views.checkotpform, name="checkotpform"),
    path('checkqrform/',views.checkqrform, name="checkqrform"),
    path('passchanged',views.passchanged,name='passchanged'),
    path('deletecheck',views.deletecheck,name='deletecheck'),

    #loginlogouturls
    path('', LoginView.as_view(template_name='authapp/login.html'), name='login'),
    path('logout/', LogoutView.as_view(template_name='authapp/logged_out.html'), name='logout'),
    path('passwordchange/',views.passwordchange,name="passwordchange"),
    path('delete/',views.delete,name="delete"),
    path('forgotuser',views.forgotuser,name="forgotuser"),
    path('password_reset/' , views.password_reset , name="password_reset"),

    path('dummy/',views.dummy,name="dummy"),
    
    path('change-password/<token>/' , views.ChangePassword , name="change_password"),

    
    #not in use
    path('reset/<uidb64>/<token>/', PasswordResetConfirmView.as_view(
        template_name='authapp/password_reset_confirm.html',
        success_url=reverse_lazy('authapp:login')), name='password_reset_confirm'),
    path('reset/done/', PasswordResetCompleteView.as_view(
        template_name='authapp/password_reset_complete.html'), name='password_reset_complete'),
    path('password_reset/', PasswordResetView.as_view(
        template_name='authapp/password_reset_form.html',
        email_template_name='authapp/password_reset_email.html',
        success_url=reverse_lazy('authapp:password_reset_done')), name='password_reset'),
    path('password_reset/done/', PasswordResetDoneView.as_view(
        template_name='authapp/password_reset_done.html'), name='password_reset_done'),

]
'''    
    path('password_change/', auth_views.PasswordChangeView.as_view(
        template_name='authapp/password_change_form.html',
        success_url=reverse_lazy('account:password_change_done')
    ), name='password_change'),
    path('password_change/done/', auth_views.PasswordChangeDoneView.as_view('authapp/password_change_done.html'), name='password_change_done'),
    #path('password_change/',PasswordChangeView.as_view(
        #template_name='authapp/password_change_form.html',

        #success_url=reverse_lazy('authapp:password_change_done')), name='password_change_done'),
    path('password_reset/', PasswordResetView.as_view(
        template_name='authapp/password_reset_form.html',
        email_template_name='authapp/password_reset_email.html',
        success_url=reverse_lazy('authapp:password_reset_done')), name='password_reset'),
    path('password_reset/done/', PasswordResetDoneView.as_view(
        template_name='authapp/password_reset_done.html'), name='password_reset_done'),
    '''