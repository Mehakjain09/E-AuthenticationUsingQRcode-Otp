from django.db import models
from django.conf import settings
from datetime import datetime,timedelta
from django.contrib.auth.models import User
from django.utils import timezone

# Create your models here.



class UserRegistrationModel(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

def get_deadline():
    return datetime.today()+timedelta(minutes=2)

class Contact(models.Model):
    #user=models.OneToOneField(User,on_delete=models.CASCADE)
    name=models.CharField(max_length=122)
    email=models.CharField(max_length=122)
    phone=models.CharField(max_length=122)
    password=models.CharField(max_length=122)
    sendtime=models.DateTimeField(null=True)
    expirytime=models.DateTimeField(default=get_deadline)
    auth_token=models.CharField(max_length=100,default="")
    is_verified=models.BooleanField(default=False)
    otp=models.CharField(max_length=122,default="")
    forget_password_token = models.CharField(max_length=100,default="")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    
