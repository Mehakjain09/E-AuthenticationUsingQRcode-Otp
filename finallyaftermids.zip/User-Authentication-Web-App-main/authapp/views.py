from django.http import request
from django.shortcuts import render,HttpResponse
from django.contrib.auth.decorators import login_required
from .forms import UserRegistration, UserEditForm
from django.conf import settings
from django.core.mail import send_mail
from django.core.mail import EmailMessage
import random
import qrcode
import cv2
from django.shortcuts import redirect
from authapp.models import Contact
import datetime
from django.contrib.auth.models import User
import uuid
from django.contrib import messages
from .models import *
import json
from twilio.rest import Client
from passlib.hash import pbkdf2_sha256



def myconverter(o):
    if isinstance(o, datetime):
        return o.__str__()

OTP=0
# Create your views here.
def send_mail_registration(email,token):
    subject="Your account needs to be verified"
    message=f'Hi paste the link to verify your account http://127.0.0.1:8000/verify/{token} '
    email_from='ssdsmbd@gmail.com'
    recipient_list=[email]
    send_mail(subject,message,email_from,recipient_list)

def verify(request,auth_token):
    try:
        profile_obj=Contact.objects.filter(auth_token=auth_token).first()
        if profile_obj:
            if profile_obj.is_verified:
                messages.error(request,"Your account has been already verified you can login ")
                return redirect('/')
            profile_obj.is_verified=True
            profile_obj.save()
            messages.success(request,"Your account has been verified ")
            return render(request,'authapp/register_success.html')
        else:
            messages.error(request,"Invalid token")
            return redirect('/')
    except Exception as e:
        print(e)
        return redirect('/')
def ChangePassword(request , token):
    context = {}
    try:
        profile_obj = Contact.objects.filter(forget_password_token = token).first()
        if(profile_obj):
            context = {'user_id' : profile_obj.name}
            
            if request.method == 'POST':
                new_password = request.POST.get('new_password')
                confirm_password = request.POST.get('reconfirm_password')
                user_id = request.POST.get('user_id')
                
                if user_id is  None:
                    messages.error(request, 'No user id found.')
                    return redirect(f'/change-password/{token}/')  
                if  new_password != confirm_password:
                    messages.error(request, 'both should  be equal.')
                    return redirect(f'/change-password/{token}/')
                user_obj = Contact.objects.get(name=user_id)
                enc_password=pbkdf2_sha256.encrypt(new_password,rounds=12000,salt_size=32)
                user_obj.password=enc_password
                user_obj.forget_password_token=""
                user_obj.save()
                messages.success(request, 'New password created.')
                return redirect('/')
        else:
            messages.error(request, 'Forgot password link is invalid')
            return redirect('/')
    except Exception as e:
        print(e)
    return render(request , 'authapp/forgot_password_reset.html' , context)
    
def registeruser(request):
    if(request.method=="POST"):
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        password=request.POST.get('password')
        confirmpassword=request.POST.get('confirmpassword')
        auth_token=str(uuid.uuid4())
        if(Contact.objects.filter(name=name).first()):
            messages.error(request,'Username is taken')
            return render(request,'authapp/register.html')
        if(Contact.objects.filter(email=email).first()):
            messages.error(request,'Email is taken')
            return render(request,'authapp/register.html')
        if(password!=confirmpassword):
            messages.error(request,'Password and Confirm Password dont match')
            return render(request,'authapp/register.html')
        enc_password=pbkdf2_sha256.encrypt(password,rounds=12000,salt_size=32)
        profile_obj=Contact.objects.create(name=name,email=email,phone=phone,password=enc_password,sendtime=datetime.now(),auth_token=auth_token)
        profile_obj.save()
        send_mail_registration(email, auth_token)
        return render(request,'authapp/register_done.html')
    else:
        return render(request,'authapp/register.html')


def checkuser(request):
    if(request.method=="POST"):
        name=request.POST.get('name')
        password=request.POST.get('password')
        objects = Contact.objects.all()
        if(not Contact.objects.filter(name=name).first()):
            messages.error(request,'Username is not present')
            return redirect('/')
        for elt in objects:
            if(elt.name==name):
                if(pbkdf2_sha256.verify(password,elt.password)):
                    if(elt.is_verified):   
                        request.session['USERNAME']=elt.name
                        request.session['EMAIL']=elt.email
                        obj =Contact.objects.get(name=request.session['USERNAME'])
                        obj.otp=random.randint(10,999999)
                        obj.save()
                        #return redirect('/choiceform')
                        return render(request,'authapp/choiceform.html')
                    else:
                        messages.error(request,'Please verify your mail')
                        return redirect('/')

                else:
                    messages.error(request,'Password is incorrect')
                    return render(request,'authapp/login.html')
        return redirect('/')
def choiceform(request):
    return render(request,'authapp/choiceform.html')
def checkotpform(request):
    return render(request,'authapp/checkotpform.html')
def checkqrform(request):
    return render(request,'authapp/checkqrform.html')
def passwordchange(request):
    return render(request,'authapp/password_change_form.html')
def delete(request):
    return render(request,'authapp/deleteform.html')
def password_reset(request):
    return render(request,'authapp/forgot_password_form.html')
def dummy(request):
    return render(request,'authapp/dummy.html')
def dashboard(request):
    return render(request,'authapp/dashboard.html')
def deletecheck(request):
    password=request.POST.get('pass')
    actualpass=Contact.objects.get(name=request.session['USERNAME']).password
    if(pbkdf2_sha256.verify(password,actualpass)):
        Contact.objects.filter(name=request.session['USERNAME']).delete()
        return render(request,'authapp/deleted_successfully.html')
    else:
        messages.error(request,'Please Enter your corrrect password')
        return render(request,'authapp/deleteform.html')
def forgotuser(request):
    user=request.POST.get('name')
    try:
        user_obj=Contact.objects.get(name=user)
        token=str(uuid.uuid4())
        user_obj.forget_password_token=token
        user_obj.save()
        send_forgot_password(user_obj.email,token)
        messages.success(request,'email is sent')
        return render(request,'authapp/forgot_password_form.html')
    except Exception as e:
        messages.error(request,'No user found with this username')
        return render(request,'authapp/forgot_password_form.html')
        
def send_forgot_password(email,token):
    subject="Your forgot password link"
    message=f'Hi, click on the link to reset your password http://127.0.0.1:8000/change-password/{token}/ '
    email_from=settings.EMAIL_HOST_USER
    receipt_list=[email]
    send_mail(subject,message,email_from,receipt_list)
    return True


def passchanged(request):
    currentpass=request.POST.get('currentpass')
    newpass=request.POST.get('newpass')
    newpasscnfrm=request.POST.get('newpasscnfrm')
    if(newpass==currentpass):
        messages.error(request,'Old Password and New Password should not match')
        return render(request,'authapp/password_change_form.html')
    if(newpass!=newpasscnfrm):
        messages.error(request,'Password and Confirm Password dont match')
        return render(request,'authapp/password_change_form.html')
    obj =Contact.objects.get(name=request.session['USERNAME'])
    enc_password=pbkdf2_sha256.encrypt(newpass,rounds=12000,salt_size=32)
    obj.password=enc_password
    obj.save()
    return render(request,'authapp/password_change_done.html')


def sendotp(request):
    if 'USERNAME' in request.session:
        rno=Contact.objects.get(name=request.session['USERNAME']).otp
        global OTP
        OTP=rno
        sid="AC5bc686c2c42ed68d3ccfd24054ad2032"
        auth_token="ccdd096e4021e53ecc617cbcfc63805c"
        twilio_num="+18125025692"
        my_phone_num="+918688652385"
        client=Client(sid,auth_token)
        message=client.messages.create(body="this is OTP "+rno,from_=twilio_num,to=my_phone_num)
        print(message.body)
        obj =Contact.objects.get(name=request.session['USERNAME'])
        obj.sendtime=datetime.now()
        obj.expirytime=datetime.now()+timedelta(minutes=2)
        obj.save()
        request.session['sendtime']=json.dumps(obj.sendtime, default = myconverter)
        request.session['expirytime']=json.dumps(obj.expirytime, default = myconverter)
        return redirect('/checkotpform')
    else:
        return render(request,'authapp/login.html')
    '''
    if 'USERNAME' in request.session:
        rno=Contact.objects.get(name=request.session['USERNAME']).otp
        global OTP
        OTP=rno
        subject="OTP Verification"
        message="Your otp is "+str(rno)
        email_from='ssdsmbd@gmail.com'
        email_to=request.session['EMAIL']
        recipient_list=[email_to,]
        send_mail(subject,message,email_from,recipient_list)
        obj =Contact.objects.get(name=request.session['USERNAME'])
        obj.sendtime=datetime.now()
        obj.expirytime=datetime.now()+timedelta(minutes=2)
        obj.save()
        request.session['sendtime']=json.dumps(obj.sendtime, default = myconverter)
        request.session['expirytime']=json.dumps(obj.expirytime, default = myconverter)
        return redirect('/checkotpform')
    else:
        return render(request,'authapp/login.html')
    '''


def checkotp(request):  
    if(request.method=='POST'):
        userotp=request.POST.get('otp')
        try:
            if(int(OTP)==int(userotp)):
                return redirect('/dashboard')   
            else:
                messages.error(request,'Enter correct otp')
                return render(request,'authapp/checkotpform.html')
        except:
            messages.error(request,'Please enter a valid otp')
            return render(request,'authapp/checkotpform.html')
        return render(request,'authapp/checkotpform.html')


def sendqr(request):
    if 'USERNAME' in request.session:
        rno=Contact.objects.get(name=request.session['USERNAME']).otp
        global OTP
        OTP=rno
        subject="QRCODE Verification"
        QRCodefile = "QRCode.png"
        QRimage = qrcode.make(OTP)
        QRimage.save(QRCodefile)
        email_to=request.session['EMAIL']
        recipient_list=[email_to,]
        msg = EmailMessage(subject, 'Your QRCODE IS ', 'ssdsmbd@gmail.com', recipient_list)
        msg.content_subtype = "html"  
        msg.attach_file('QRCode.png')
        msg.send()
        return redirect('/checkqrform')
def checkqr(request):
    if(request.method=='POST' and 'checkotp' in request.POST):
        userotp=request.POST.get('otp')
        try:
            if(int(OTP)==int(userotp)):
                return redirect('/dashboard')   
            else:
                messages.error(request,'Enter correct otp')
                return render(request,'authapp/checkqrform.html')
        except:
            messages.error(request,'Please enter a valid otp')
            return render(request,'authapp/checkqrform.html')
        return render(request,'authapp/checkqrform.html')
    elif(request.method=='POST' and 'checkqrcode' in request.POST):
        #attach=request.POST.get('qr', False)
        doc=request.FILES
        attach=doc['qrimage']
        image = cv2.imread(attach.name)
        try:
            detector = cv2.QRCodeDetector()
            data, vertices_array, binary_qrcode = detector.detectAndDecode(image)
            if vertices_array is not None:
                try:
                    #print(Contact.objects.get(name=request.session['USERNAME']).otp,data)
                    if(int(Contact.objects.get(name=request.session['USERNAME']).otp)==int(data)):
                        return redirect('/dashboard')   
                    else:
                        messages.error(request,'Upload correct QR')
                        return render(request,'authapp/checkqrform.html')
                except:
                    messages.error(request,'Please enter a valid otp')
                    return render(request,'authapp/checkqrform.html')
                return render(request,'authapp/checkqrform.html')
            else:
                print("There was some error in uploading file")
        except:
            print("you have not enterred correct format of qr code")
            messages.error(request,'Enter a corect form of QR')
            return render(request,'authapp/checkqrform.html')
        return render(request,'authapp/checkqrform.html')
    elif(request.method=='POST' and 'web' in request.POST):
        context={'post':Contact.objects.get(name=request.session['USERNAME']).otp}
        return render(request,'authapp/web.html',context)
    return render(request,'authapp/checkqrform.html')



    

''' 
def dashboard(request):
    context = {
        "welcome": "Welcome to your dashboard"
    }
    return render(request, 'authapp/dashboard.html', context=context)



def register(request):
    if request.method == 'POST':
        form = UserRegistration(request.POST or None)
        if form.is_valid():
            new_user = form.save(commit=False)
            new_user.set_password(
                form.cleaned_data.get('password')
            )
            new_user.save()
            return render(request, 'authapp/register_done.html')
    else:
        form = UserRegistration()

    context = {
        "form": form
    }

    return render(request, 'authapp/register.html', context=context)


def edit(request):
    if request.method == 'POST':
        user_form = UserEditForm(instance=request.user,
                                 data=request.POST)
        if user_form.is_valid():
            user_form.save()
    else:
        user_form = UserEditForm(instance=request.user)
    context = {
        'form': user_form,
    }
    return render(request, 'authapp/edit.html', context=context)

'''

'''
def send(request):
    subject="hello"
    message="helloooooooo"
    email_from=settings.EMAIL_HOST_USER
    recipient_list=['kalamehakjain@gmail.com',]
    send_mail(subject,message,enail_from,recipient_list)
    print('sucesssss!!!')
'''


'''README.md
import os
import smtplib
import imghdr
from email.message import EmailMessage

email_id='Ssdsmbd@gmail.com'
email_psswd='pvzjniisfgtykpwf'
msg=EmailMessage()
msg['Subject'] = 'subject'
msg['From'] = email_id
msg['To'] = 'kalamehakjain@gmail.com'
with open('hello.jpg','rb') as m:
    file_data=m.read()
    file_type=imghdr.what(m.name)
    file_name=m.name 
print(file_type)
msg.add_attachment(file_data,maintype='image',subtype=file_type,filename=file_name)
with smtplib.SMTP_SSL('smtp.gmail.com',587) as smtp:
    smtp.login(email_id,email_psswd)
    smtp.send_message(msg)


'''
